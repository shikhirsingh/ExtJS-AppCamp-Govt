Ext.define('AppCamp.view.spendingdetail.SpendingDetailViewController', {
	extend: 'Ext.app.ViewController',
	alias: 'controller.spendingdetailview'
});
