Ext.define('AppCamp.view.spendingdetail.SpendingDetailView',{
	extend: 'Ext.Container',
	xtype: 'spendingdetailview',
	requires: [
		'AppCamp.view.spendingdetail.SpendingDetailViewController',
		'AppCamp.view.spendingdetail.SpendingDetailViewModel'
	],

	controller: 'spendingdetailview',
	viewModel: 'spendingdetailview',

	html: 'spendingdetailview'
});
