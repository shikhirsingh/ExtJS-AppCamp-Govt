Ext.define('AppCamp.view.spendingdetail.SpendingDetailView',{
	extend: 'Ext.Container',
	xtype: 'spendingdetailview',
	controller: 'spendingdetailview',
	viewModel: 'spendingdetailview',

	html: 'spendingdetailview'
});
