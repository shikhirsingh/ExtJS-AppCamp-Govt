Ext.define('AppCamp.view.spendingdetail.SpendingDetailViewModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.spendingdetailview',
	data: {
			name: 'AppCamp'
	}
});
