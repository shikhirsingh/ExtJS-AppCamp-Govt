Ext.define('AppCamp.view.agencies.AgenciesViewModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.agenciesview',
	data: {
		name: 'AppCamp'
	}
});
