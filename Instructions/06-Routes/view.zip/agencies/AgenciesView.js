Ext.define('AppCamp.view.agencies.AgenciesView',{
	extend: 'Ext.Container',

	requires:[
		'AppCamp.view.agencies.AgenciesViewController',
		'AppCamp.view.agencies.AgenciesViewModel'
	],
	xtype: 'agenciesview',
	controller: 'agenciesview',
	viewModel: 'agenciesview',
	html: 'agenciesview'
});
