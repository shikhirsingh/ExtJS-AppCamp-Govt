Ext.define('AppCamp.view.agencies.AgenciesView',{
	extend: 'Ext.Container',
	xtype: 'agenciesview',
	controller: 'agenciesview',
	viewModel: 'agenciesview',

	html: 'agenciesview'
});
