Ext.define('AppCamp.view.agencies.AgenciesViewController', {
	extend: 'Ext.app.ViewController',
	alias: 'controller.agenciesview'
});
