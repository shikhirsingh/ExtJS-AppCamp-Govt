Ext.define('AppCamp.view.dashboard.DashboardView',{
	extend: 'Ext.Container',
	requires: [
		'AppCamp.view.dashboard.DashboardViewController',
		'AppCamp.view.dashboard.DashboardViewModel'
	],
	xtype: 'dashboardview',
	controller: 'dashboardview',
	viewModel: 'dashboardview',

	html: 'dashboardview'
});
