Ext.define('AppCamp.view.dashboard.DashboardView',{
	extend: 'Ext.Container',
	xtype: 'dashboardview',
	controller: 'dashboardview',
	viewModel: 'dashboardview',

	html: 'dashboardview'
});
