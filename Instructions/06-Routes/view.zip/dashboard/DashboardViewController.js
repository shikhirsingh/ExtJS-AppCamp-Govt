Ext.define('AppCamp.view.dashboard.DashboardViewController', {
	extend: 'Ext.app.ViewController',
	alias: 'controller.dashboardview'
});
