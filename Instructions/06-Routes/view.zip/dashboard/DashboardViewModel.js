Ext.define('AppCamp.view.dashboard.DashboardViewModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.dashboardview',
	data: {
		name: 'AppCamp'
	}
});
